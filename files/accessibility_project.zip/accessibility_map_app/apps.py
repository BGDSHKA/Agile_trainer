from django.apps import AppConfig


class AccessibilityMapAppConfig(AppConfig):
    name = 'accessibility_map_app'
