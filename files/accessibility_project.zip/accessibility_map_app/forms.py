from django import forms
from accessibility_map_app.models import *
from django.contrib.auth.models import User


class SpotForm(forms.ModelForm):
    """
    Форма добавления новой точки.
    В качестве полей ввода используются следующие поля из таблицы:
    - Код карты
    - Координата новой точки по х
    - Координата новой точки по у
    """

    class Meta:
        model = Spot
        fields = ('map', 'coordinate_x', 'coordinate_x')


class CommentaryForm(forms.ModelForm):
    """
    Форма добавления нового комментария.
    В качестве полей ввода используются следующие поля из таблицы:
    - Текст коментария
    """

    class Meta:
        model = Spot
        fields = ('text',)


class CommentaryListForm(forms.ModelForm):
    """
    Форма добавления нового элемента в список коментариев.
    В качестве полей ввода используются следующие поля из таблицы:
    - Код точки
    - Код коментария
    - Код автора коментария
    """

    class Meta:
        model = Spot
        fields = ('spot', 'commentary', 'author')


class UserRegistrationForm(forms.ModelForm):
    """
    Форма регистрации нового пользователя
     В качестве полей ввода используются следующие поля из таблицы:
    - Имя пользователя
    - Пароль
    - Электронная почта
    """
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'password', 'email')


class UserLoginForm(forms.ModelForm):
    """
    Форма входа зарегестрированного пользователя
     В качестве полей ввода используются следующие поля из таблицы:
    - Имя пользователя
    - Пароль
    """
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = User
        fields = ('username', 'password')
