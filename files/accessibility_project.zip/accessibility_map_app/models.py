from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models
from django.contrib.auth.models import User


class Map(models.Model):
    """
    Модель карты для базы данных. Хранит информацию о картах
    """
    # Первичный ключ с кодом карты добавляется автоматически

    width = models.FloatField(verbose_name='Ширина карты')
    height = models.FloatField(verbose_name='Высота карты')
    scale = models.FloatField(verbose_name='Маcштаб')


class Spot(models.Model):
    """
    Модель точки для базы данных. Хранит информацию о точке на карте
    """
    # Первичный ключ с кодом точки добавляется автоматически

    map = models.ForeignKey(Map, verbose_name='Карта', on_delete=models.CASCADE)
    coordinate_x = models.FloatField(verbose_name='Координата Х точки',
                                     validators=[MaxValueValidator(lambda self: self.map.width),
                                                 MinValueValidator(0)], )
    coordinate_y = models.FloatField(verbose_name='Координата У точки',
                                     validators=[MaxValueValidator(lambda self: self.map.height),
                                                 MinValueValidator(0)], )

    def __str__(self):
        """
        Текстовое представление точки из базы данных
        :return: Описание точки с кодом карты и координатами на ней
        """
        return f'Точка на карте {self.map.id}, ' \
               f'c координатами ({self.coordinate_x};{self.coordinate_y})'


class Commentary(models.Model):
    """
    Модель коментария для базы данных. Хранит информацию о содержании комментария
    """
    # Первичный ключ с кодом коментария добавляется автоматически

    text = models.CharField(verbose_name='Текст коментария', max_length=500)

    def __str__(self):
        """
        Текстовое представления коментария из базы данных
        :return: Содержимое комментария с его кодом
        """
        return f'{self.id}: {self.text}'


class CommentaryList(models.Model):
    """
    Модель списка коментариев для базы данных. Хранит информацию о коментариях к точкам
    """
    spot = models.ForeignKey(Spot, verbose_name='Точка для комментария', on_delete=models.CASCADE)
    commentary = models.ForeignKey(Commentary, verbose_name='Комментарий', on_delete=models.CASCADE)
    author = models.ForeignKey(User, verbose_name='Пользователь', on_delete=models.CASCADE)

    class Meta:
        unique_together = (('spot', 'commentary'),)

    def __str__(self):
        """
        Текстовое представления элемента списка коментариев из базы данных
        :return: Код точки, имя автора и первые 50 символов коментария
        """
        return f'Точка {self.spot}, ' \
               f'пользователь {self.author.username}, ' \
               f'коментарий: {self.commentary.text[:50]}'


# Запросы


def get_users_number():
    """
    Запрос количества пользователей
    :return: Количество пользователей в базе данных
    """
    return User.objects.all().count()


def get_spots_number():
    """
    Запрос количества точек
    :return: Количество точек в базе данных
    """
    return Spot.objects.all().count()


def get_commentary_number():
    """
    Запрос количества коментариев
    :return: Количество коментариев в базе данных
    """
    return Commentary.objects.all().count()


# Процедуры #


def search_spots(map_id, x1, y1, x2, y2):
    """
    Отбор точек в указанной области
    :param map_id: Код карты для поиска
    :param x1: Левая граница
    :param y1: Верхняя граница
    :param x2: Правая граница
    :param y2: Нижняя граница
    :return: Элементы таблицы Точки только из указанной области
    """
    return Spot.objects.filter(map=map_id,
                               coordinate_x__gte=x1, coordinate_x__lte=x2,
                               coordinate_y__gte=y1, coordinate_y__lte=y2)


def get_comments_for_spot(spot_id):
    """
    Отбор всех комментариев к определённой точке
    :param spot_id: Код точки для поиска
    :return: Все коментарии с содержимым и пользователями
    """
    return CommentaryList.objects.filter(spot=spot_id).select_related('commentary').select_related('author')


def get_spots(map_id):
    """
    Отбор всех точек для определённой карты
    :param map_id: Код карты для поиска
    :return: Все точки для указанной карты
    """
    return Spot.objects.filter(map=map_id)


def get_map_scale(map_id):
    """
    Получение масштаба для определённой карты
    :param map_id: Код карты
    :return: Масштаб для указанной карты
    """
    return Map.objects.get(pk=map_id).scale


def get_map_height(map_id):
    """
    Получение высоты для определённой карты
    :param map_id: Код карты
    :return: Высота для указанной карты
    """
    return Map.objects.get(pk=map_id).height


def get_map_width(map_id):
    """
    Получение Ширины для определённой карты
    :param map_id: Код карты
    :return: Ширина для указанной карты
    """
    return Map.objects.get(pk=map_id).width


User.username_validator = RegexValidator(r'^[\d.A-Za-z]{1,15}$', message='Имя пользователя может состоять только из '
                                                                         'латинских букв, цифр и точек')
